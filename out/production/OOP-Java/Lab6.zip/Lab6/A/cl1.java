package Lab6.A;

public class cl1 {
    public void disp() {
        System.out.println("Hello i am in package A and file cl1");
    }
}
